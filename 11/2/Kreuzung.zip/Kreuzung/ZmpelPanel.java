import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * Stellt eine Zmpel graphisch dar.
 *  
 * @author Fredrik Winkler
 * @author Christian Spaeh
 * @version Januar 2018
 */
class ZmpelPanel extends JPanel
{
    private Zmpel _ampel;
    private JButton _roteLampe;
    private JButton _gelbeLampe;
    private JButton _grueneLampe;

    /**
     * Initialisiert eine neue Ampeldarstellung mit einer gegebenen Ampel.
     * 
     * @param ampel die darzustellende Ampel
     */
    public ZmpelPanel(Zmpel ampel)
    {
        _ampel = ampel;
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        initialisiereLampen();
        aktualisiereLampen();
    }

    /**
     * Erzeugt fuer jede Lampe einen Button.
     */
    private void initialisiereLampen()
    {
        _roteLampe = neueLampe();
        _gelbeLampe = neueLampe();
        _grueneLampe = neueLampe();
    }

    /**
     * Erzeugt einen LampenButton.
     */
    private JButton neueLampe()
    {
        JButton lampe = new JButton("\u25c9");
        lampe.setFont(font);
        lampe.setBackground(Color.LIGHT_GRAY);
        lampe.setForeground(Color.BLACK);
        add(lampe);
        return lampe;
    }

    private static final Font font = new Font(Font.MONOSPACED, Font.PLAIN, 50);

    /**
     * Setzt die Farben der LampenButtons entsprechend der Phase der verwendetet Ampel.
     */
    public void aktualisiereLampen()
    {
        _roteLampe.setForeground(_ampel.leuchtetRot() ? Color.RED : Color.BLACK);
        _gelbeLampe.setForeground(_ampel.leuchtetGelb() ? Color.YELLOW : Color.BLACK);
        _grueneLampe.setForeground(_ampel.leuchtetGruen() ? Color.GREEN : Color.BLACK);
    }
}
