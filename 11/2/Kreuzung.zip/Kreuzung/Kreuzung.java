/**
 * Eine Kreuzung besteht aus 2 logischen Ampeln:
 * eine für die horizonale Richtung, und eine für die vertikale.
 * 
 * @author Fredrik Winkler
 * @version Januar 2018
 */
public class Kreuzung
{
}
