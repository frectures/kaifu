import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Stellt eine Kreuzung graphisch dar und ermoeglicht das Weiterschalten per Knopfdruck.
 *  
 * @author Fredrik Winkler
 * @author Christian Spaeh
 * @version Januar 2018
 */
class KreuzungGUI
{
    private Kreuzung _kreuzung;

    private JFrame _frame;
    private ZmpelPanel _norden;
    private ZmpelPanel _westen;
    private ZmpelPanel _osten;
    private ZmpelPanel _sueden;
    
    /**
     * Erzeugt eine neue Kreuzung und stellt diese anschliessend dar.
     */
    public KreuzungGUI()
    {
        this(new Kreuzung());
    }

    /**
     * Initialisiert eine neue Kreuzung-Darstellung mit einer gegebenen Kreuzung.
     * 
     * @param kreuzung die darzustellende Kreuzung
     */
    private KreuzungGUI(Kreuzung kreuzung)
    {
        _kreuzung = kreuzung;
        initialisiereFrame();
        initialisiereAmpeln();
        aktualisiereAmpeln();
        macheGUIsichtbar();
    }

    /**
     * Konfiguriert den Fenstertitel und das Layout.
     */
    private void initialisiereFrame()
    {
        _frame = new JFrame("Kreuzung");
        _frame.setLayout(new GridLayout(3, 3));
    }

    private void initialisiereAmpeln()
    {
        _frame.add(new JPanel());
        _frame.add(_norden = new ZmpelPanel(_kreuzung.gibVertikaleAmpel()));
        _frame.add(new JPanel());
        _frame.add(_westen = new ZmpelPanel(_kreuzung.gibHorizontaleAmpel()));
        _frame.add(weiterButton());
        _frame.add(_osten = new ZmpelPanel(_kreuzung.gibHorizontaleAmpel()));
        _frame.add(new JPanel());
        _frame.add(_sueden = new ZmpelPanel(_kreuzung.gibVertikaleAmpel()));
        _frame.add(new JPanel());
    }
    
    /**
     * Erzeugt den Weiter-Button und fuegt einen ActionListener hinzu,
     * der die Ampeln weiterschaltet, wenn der Button gedrueckt wird.
     */
    private JButton weiterButton()
    {
        JButton weiter = new JButton("weiter");
        weiter.addActionListener(this::schalteWeiter);
        return weiter;
    }

    private void schalteWeiter(ActionEvent event)
    {
        _kreuzung.schalteWeiter();
        aktualisiereAmpeln();
    }
    
    private void aktualisiereAmpeln()
    {
        _norden.aktualisiereLampen();
        _westen.aktualisiereLampen();
        _osten.aktualisiereLampen();
        _sueden.aktualisiereLampen();
    }

    /**
     * Setzt die DefaultCloseOperation, packt das Frame auf die richtige Groesse und macht es
     * sichtbar.
     */
    private void macheGUIsichtbar()
    {
        _frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        _frame.pack();
        _frame.setVisible(true);
    }
}
